package com.example.assignment1_map524_stellajung;

import android.content.Context;
import android.content.res.Resources;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class QuestionBankManager {

    private QuestionBank questionBank;
    private List<Integer> scoreHistory;

    public QuestionBankManager(List<String> questions, List<String> answers, List<Integer> colors, List<Integer> orders, int position, int score) {
        if(position == -1) {
            position = 0;
        }

        questionBank = new QuestionBank(questions, answers, colors, orders, position, score);
//        Resources r = context.getResources();
//        if(questions == null) {
//            questionBank.addQuestion(r.getString(R.string.question1), "true");
//            questionBank.addQuestion(r.getString(R.string.question2), "false");
//            questionBank.addQuestion(r.getString(R.string.question3), "true");
//            questionBank.addQuestion(r.getString(R.string.question4), "true");
//            questionBank.addQuestion(r.getString(R.string.question5), "true");
//            questionBank.addColors(r.getIntArray(R.array.colors));
//        }

    }

    public QuestionBank getQuestionBank() {
        return questionBank;
    }

    public void setQuestions(List<Question> questions) {
        questionBank.setQuestions(questions);
    }

    public void setScoreHistory(int score) {scoreHistory.add(score);}

//    @Override
//    public int describeContents() {
//        return this.hashCode();
//    }
//
//    @Override
//    public void writeToParcel(Parcel dest, int flags) {
//        dest.writeParcelable(questionBank, flags);
//    }
}
