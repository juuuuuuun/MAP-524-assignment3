package com.example.assignment1_map524_stellajung;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Fragment;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String LANG_OPTION = "langOption";
    private static final String ORDERS = "questions";
    private static final String COLORS = "colors";
    private static final String POSITION = "position";
    private static final String SCORE = "score";

    private Button trueButton;
    private Button falseButton;
    private ProgressBar progress;
    private QuestionBankManager questionBankManager;
    private List<String> questions;
    private List<String> answers;
    private String currentQuestion;
    private int currentColor;
    private RadioButton englishButton;
    private RadioButton frenchButton;
    private RadioGroup radio;
    private int language = 1;
    private Locale locale;
    private AlertDialog.Builder alertBox;
    private FragmentManager fm;
    private Fragment questionFragment;
    private FragmentTransaction transaction;

    private StorageManager storageManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        if(savedInstanceState != null) {
            language = savedInstanceState.getInt(LANG_OPTION);

            renderView(language);

            locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;

        }

        prepareForQuizAndStart();

        radio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (frenchButton.isChecked()) {
                    locale = new Locale("fr");
                    language = 2;
                } else {
                    locale = new Locale("en");
                    language = 1;
                }

                Locale.setDefault(locale);
                Configuration config = new Configuration();
                config.locale = locale;

                Intent intent = new Intent(getApplicationContext(), MainActivity.class);

                getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());

                intent.putExtra(LANG_OPTION, language);

                intent.putExtra(COLORS, (Serializable) questionBankManager.getQuestionBank().getColors());
                intent.putExtra(ORDERS, (Serializable) questionBankManager.getQuestionBank().getOrders());
                intent.putExtra(POSITION, questionBankManager.getQuestionBank().getPosition() - 1);
                intent.putExtra(SCORE, questionBankManager.getQuestionBank().getScore());

                setResult(Activity.RESULT_OK, intent);
                finish();
                startActivity(intent);
            }
        });


    }

    private void init() {
        radio = findViewById(R.id.language);
        englishButton = findViewById(R.id.englishB);
        frenchButton = findViewById(R.id.frenchB);
        trueButton = findViewById(R.id.trueButton);
        falseButton = findViewById(R.id.falseButton);
        trueButton.setOnClickListener(this);
        falseButton.setOnClickListener(this);

        storageManager = new StorageManager();
        storageManager = new StorageManager();
        getQuestionsAndAnswers();

    }

    private void prepareForQuizAndStart() {
        Intent intent = getIntent();
        language = intent.getIntExtra(LANG_OPTION, 0);
//        QuestionBank test = intent.getParcelableExtra("test");
//        String temp = getString(R.string.question1);
//        String temp2 = getString(R.string.French);
//        String temp1 = frenchButton.getText().toString();
//        List<Question> questions = intent.getParcelableArrayListExtra(QUESTIONS);
        List<Integer> orders = intent.getIntegerArrayListExtra(ORDERS);
        List<Integer> colors = intent.getIntegerArrayListExtra(COLORS);
        int position = intent.getIntExtra(POSITION, -1);
        int score = intent.getIntExtra(SCORE, 0);
//        questionBankManager = intent.getParcelableExtra(BANK_MANAGER);
//        if(questionBankManager == null) {
        if(colors == null) {
            int[] c = getResources().getIntArray(R.array.colors);
            colors = new ArrayList<>(7);
            for (int i : c) {
                colors.add(i);
            }
        }
        // getting data from intent everytime
        questionBankManager = new QuestionBankManager(questions, answers, colors, orders, position, score);

        progress = findViewById(R.id.progressBar);
        alertBox = new AlertDialog.Builder(this);
        renderView(language);

        fm = getFragmentManager();

        startOver(position);
    }

    void renderView(int language) {
        if(language == 2) {
            locale = new Locale("fr");
            frenchButton.setChecked(true);
        }else {
            locale = new Locale("en");
            englishButton.setChecked(true);
        }
    }

    // onclick method for true & false button
    @Override
    public void onClick(View v) {
        QuestionBank questionBank = questionBankManager.getQuestionBank();


        switch (v.getId()) {
            case R.id.trueButton:
                if(questionBank.isAnswer(currentQuestion, true)) {
                    Toast.makeText(getApplicationContext(), R.string.correct_message, Toast.LENGTH_SHORT).show();
                } else{
                    Toast.makeText(getApplicationContext(), R.string.incorrect_message, Toast.LENGTH_SHORT).show();
                }
//                transaction.replace(R.id.q_fragment, questionFragment);
//                .commit();

//                transaction.remove(questionFragment).setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN).commit();
//                Log.d("message", "fragment removed");
//                transaction.add(R.id.q_fragment, questionFragment).setTransition(FragmentTransaction.TRANSIT_FRAGMENT_CLOSE).commit();
//                Log.d("message", "fragment added");

                break;
            case R.id.falseButton:
                if(questionBank.isAnswer(currentQuestion, false)) {
                    Toast.makeText(getApplicationContext(), R.string.correct_message, Toast.LENGTH_SHORT).show();
                } else{
                    Toast.makeText(getApplicationContext(), R.string.incorrect_message, Toast.LENGTH_SHORT).show();
                }
                break;

        }
        progress.setProgress(questionBank.getProgress());

        if(!questionBank.isFinal()) {
            currentColor = questionBank.getColor();
            currentQuestion = questionBank.getQuestion();
            questionFragment = QuestionFragment.newInstance(currentQuestion, currentColor);
            transaction = fm.beginTransaction();
            transaction.replace(R.id.q_fragment, questionFragment).commit();
//          questionFragment = fm.findFragmentById(R.id.q_fragment);
//        transaction = fm.beginTransaction();
//transaction.remove(questionFragment);
//transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_CLOSE).commit();
        } else {
            alertBox.setMessage("Your Score is: " + questionBank.getScore() + " out of " + questionBank.getSize())
                    .setCancelable(false)
                    .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    })
                    .setPositiveButton("REPEAT", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            startOver(-1);
                        }
                    });
            AlertDialog alert = alertBox.create();
            alert.setTitle("Result");
            alert.show();
            storageManager.saveInternalStorage(this, String.valueOf(questionBank.getScore()));
        }
//        transaction.detach(questionFragment);
//        transaction.attach(questionFragment);
//        transaction.commit();
//        transaction.replace(R.id.q_fragment, new QuestionFragment()).addToBackStack(null).commit();
    }

    public void startOver(int position) {
        QuestionBank questionBank = questionBankManager.getQuestionBank();
        if(position == -1) {
            questionBank.start();
        }
        progress.setMax(questionBank.getSize());
        progress.setProgress(questionBank.getProgress());
        currentColor = questionBank.getColor();
        currentQuestion = questionBank.getQuestion();
        questionFragment = QuestionFragment.newInstance(currentQuestion, currentColor);
        transaction = fm.beginTransaction();
        transaction.replace(R.id.q_fragment, questionFragment).commit();

    }

    public void getQuestionsAndAnswers() {
        questions = new ArrayList<>();
        questions.add(getString(R.string.question1));
        questions.add(getString(R.string.question2));
        questions.add(getString(R.string.question3));
        questions.add(getString(R.string.question4));
        questions.add(getString(R.string.question5));
        answers = new ArrayList<>();
        answers.add(getString(R.string.answer1));
        answers.add(getString(R.string.answer2));
        answers.add(getString(R.string.answer3));
        answers.add(getString(R.string.answer4));
        answers.add(getString(R.string.answer5));
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(LANG_OPTION,language);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.quiz_result_menu, menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item){
        super.onOptionsItemSelected(item);
        switch(item.getItemId()) {
            case R.id.average:
//                Intent averageIntent = new Intent(this, QuestionBank.class);
                String data = storageManager.loadFromInternalStorage(this);
                int total = 0;
                char[] nums = data.toCharArray();
                for(char c : nums) {
                    try {
                        total += (int)(c - '0');
                    } catch (NumberFormatException e) {
                        total = 0;
                    }
                }
                double avg = (double)total / nums.length;


//                averageIntent.putExtra("averageScroe", avg);
//                startActivity(averageIntent);
                Dialog newDialog = Dialog.newInstance(avg);
                transaction = fm.beginTransaction();
                newDialog.show(transaction, "average");
//                alertBox.setMessage("Your average is:" +  averageIntent )
//                        .setCancelable(false)
//                        .setPositiveButton("close", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//                                finish();
//                            }
//                        });
                break;
            case R.id.reset:
                    storageManager.resetInternalStorage(this);
                break;


        }
        return true;
    }
}