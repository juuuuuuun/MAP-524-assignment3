package com.example.assignment1_map524_stellajung;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.app.Fragment;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class QuestionFragment extends Fragment {
    private static final String TEXT_KEY = "TEXT_KEY";
    private static final String COLOR_KEY = "COLOR_KEY";
    private static final String LANGUAGE_KEY = "LANGUAGE_KEY";

    private String question;
    private int colorId;

    TextView questionTextView;
    LinearLayout fLayout;

    public static QuestionFragment newInstance(String question, int colorId) {

        Bundle bundle = new Bundle();

        QuestionFragment fragment = new QuestionFragment();
        bundle.putString(TEXT_KEY, question);
        bundle.putInt(COLOR_KEY, colorId);

        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            question = getArguments().getString(TEXT_KEY);
            colorId = getArguments().getInt(COLOR_KEY);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.question_fragment, container,false);

        fLayout = view.findViewById(R.id.fLayout);
        fLayout.setBackgroundColor(colorId);

        questionTextView = view.findViewById(R.id.q);
        questionTextView.setText(question);
//        questionTextView.setBackgroundColor(colorId);

        return view;
    }

}
