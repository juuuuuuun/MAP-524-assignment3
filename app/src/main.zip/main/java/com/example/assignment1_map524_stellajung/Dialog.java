package com.example.assignment1_map524_stellajung;

import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.text.DecimalFormat;


public class Dialog extends DialogFragment implements View.OnClickListener {
    public static String AVERAGE = "average";

    private double avg;

    public static Dialog newInstance (double passedAverage) {
        Dialog dialog = new Dialog();
        Bundle bundle = new Bundle();
        bundle.putDouble(AVERAGE, passedAverage);
        dialog.setArguments(bundle);
        return dialog;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            avg = getArguments().getDouble(AVERAGE);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        DecimalFormat decimalFormat = new DecimalFormat("0.##");
        View view = inflater.inflate(R.layout.dialog_fragment, container, false);
        TextView textView = view.findViewById(R.id.resultId);
        textView.setText("Average score is " + decimalFormat.format(avg));
        Button button = view.findViewById(R.id.close_dialog);
        button.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        dismiss();
    }
}
