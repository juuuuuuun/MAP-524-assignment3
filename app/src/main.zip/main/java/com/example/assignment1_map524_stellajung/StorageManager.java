package com.example.assignment1_map524_stellajung;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class StorageManager {

    private static final String TAG = "STORAGEMANAGER";

    public void resetInternalStorage(Activity activity) {
        try(FileOutputStream fileOutputStream = activity.openFileOutput("average.txt", Context.MODE_PRIVATE)) {
            File file = activity.getFilesDir();
            fileOutputStream.write("".getBytes());
            Toast.makeText(activity, "Reset in " + file + " average.txt", Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveInternalStorage(Activity activity, String result) {
        try(FileOutputStream fileOutputStream = activity.openFileOutput("average.txt", Context.MODE_APPEND)) {
            File file = activity.getFilesDir();
            fileOutputStream.write(result.getBytes());
            Toast.makeText(activity, "Saved " + result + " in " + file + " average.txt", Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String loadFromInternalStorage(Activity activity){
        String loadedData = "";

        try(FileInputStream fileInputStream = activity.openFileInput("average.txt")) {
            int read = -1;
            StringBuffer buffer = new StringBuffer();
            while ((read = fileInputStream.read()) != -1){
                buffer.append((char) read);
            }
            loadedData = buffer.toString();
        }catch(Exception e){
            e.printStackTrace();
        }
        return loadedData;
    }
}
